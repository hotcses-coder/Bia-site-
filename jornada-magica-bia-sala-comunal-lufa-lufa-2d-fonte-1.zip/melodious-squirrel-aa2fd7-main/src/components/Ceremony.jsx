import { useEffect, useRef, useState } from "react";
import { magicAudio } from "../lib/audio";

const INTRO_DURATION = 16800;
const TRANSITION_DURATION = 1400;

export default function Ceremony({ onEnded }) {
  const sceneRef = useRef(null);
  const videoRef = useRef(null);
  const [showVideo, setShowVideo] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowVideo(true), INTRO_DURATION);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !showVideo) return;

    let cancelled = false;
    const startVideo = async () => {
      video.currentTime = 0;
      try {
        await video.play();
      } catch {
        video.muted = true;
        try {
          await video.play();
        } catch {
          // The browser may block playback; the user can still use the native controls if needed.
        }
      }
    };

    if (!cancelled) startVideo();

    const handleEnded = () => {
      if (isExiting) return;
      setIsExiting(true);
      window.setTimeout(() => {
        magicAudio.chime(523.25);
        onEnded();
      }, TRANSITION_DURATION);
    };

    const handleVisibility = () => {
      if (document.hidden) {
        video.pause();
      } else if (!isExiting) {
        video.play().catch(() => {});
      }
    };

    video.addEventListener("ended", handleEnded);
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      cancelled = true;
      video.pause();
      video.removeEventListener("ended", handleEnded);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [showVideo, isExiting, onEnded]);

  return (
    <section
      ref={sceneRef}
      className={`ceremony-video-scene ${showVideo ? "is-video" : "is-intro"} ${
        isExiting ? "is-exiting" : ""
      }`}
      aria-label="Cerimônia de seleção da Bia"
    >
      <div className="ceremony-intro" aria-live="polite">
        <div className="ceremony-intro-copy">
          <span className="eyebrow">A CERIMÔNIA DO PERTENCIMENTO</span>
          <div className="ceremony-intro-lines">
            <p>
              Vamos lá, Bia…
              <br />
              <em>acho que nos atrasamos um pouco para a cerimônia.</em>
            </p>
            <p>
              Não podemos perder
              <br />
              <em>este grande dia para você.</em>
            </p>
            <p>
              Aliás, não é todo dia
              <br />
              <em>que se fazem 17 anos, né?</em>
            </p>
          </div>
        </div>
      </div>

      <div className="ceremony-video-wrap" aria-hidden={!showVideo}>
        <video
          ref={videoRef}
          className="ceremony-video"
          src="/video/cerimonia-selecao-bia.mp4"
          playsInline
          preload="auto"
          aria-label="Vídeo completo da cerimônia de seleção"
        />
      </div>

      <div className="ceremony-transition" aria-hidden="true" />
    </section>
  );
}
