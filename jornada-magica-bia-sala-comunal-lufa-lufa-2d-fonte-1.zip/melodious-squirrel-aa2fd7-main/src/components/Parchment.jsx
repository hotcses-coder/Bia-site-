import { useEffect, useRef } from "react";
import { X } from "lucide-react";

export default function Parchment({ memory, destination, onClose }) {
  const ref = useRef(null);
  const item = memory || destination;
  useEffect(() => {
    const dialog = ref.current;
    if (item && !dialog.open) dialog.showModal();
    else if (!item && dialog.open) dialog.close();
  }, [item]);
  return (
    <dialog
      ref={ref}
      className={`parchment-dialog ${memory?.image ? "has-photo" : ""}`}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      aria-labelledby="memory-title"
    >
      {item && (
        <div className="parchment-sheet">
          <button
            className="parchment-close"
            onClick={onClose}
            aria-label="Fechar pergaminho"
          >
            <X size={22} />
          </button>
          {memory?.image ? (
            <>
              <div className="memory-photo">
                <img src={memory.image} alt={memory.alt} />
              </div>
              <div className="parchment-writing">
                <p className="memory-message">{memory.message}</p>
              </div>
            </>
          ) : (
            <div className="parchment-writing">
              <p className="memory-message">
                {destination
                  ? destination.description ||
                    "Esta passagem ainda guarda seus segredos. Em breve, novas pessoas e lembranças especiais encontram um lar por aqui."
                  : "Este quadro guarda um lugar para uma amizade especial. A próxima memória ainda está sendo escrita."}
              </p>
            </div>
          )}
        </div>
      )}
    </dialog>
  );
}
