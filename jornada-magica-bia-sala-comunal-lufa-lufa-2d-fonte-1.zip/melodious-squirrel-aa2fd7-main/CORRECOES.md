# Correções aplicadas — Jornada Mágica da Bia

## Correções funcionais

- Corrigida a associação das duas memórias reais na Academia:
  - `foto_01_sofia.jpg` agora exibe a mensagem curta de Sofia.
  - `foto_02_volei.jpg` agora exibe a mensagem de aniversário sobre o vôlei.
- A Sala Comunal foi mantida como destino disponível, porque já existe uma implementação Three.js completa.
- A Sala Comunal agora recebe o callback de entrada na Câmara das Memórias; ao concluir o puzzle e tocar em `ENTRAR NAS MEMÓRIAS`, a jornada retorna à Academia.
- Corrigido o ciclo de vida da cena Three.js: a cena não é mais desmontada e reconstruída a cada mudança do estado `entered`.
- Adicionada referência estável para detectar a abertura da porta sem fechar/recriar a cena.
- Adicionado tratamento de `prefers-reduced-motion` para a abertura da porta da Sala Comunal.
- O canvas da Sala Comunal recebeu uma descrição acessível.
- O cálculo da largura dos cenários agora acompanha redimensionamentos/orientação da janela.
- Timers internos são removidos da lista assim que terminam e são limpos no desmontagem.
- Corrigida a frase do rodapé para `Deixe a curiosidade guiar você`.
- No modo de movimento reduzido, os três textos da cerimônia ficam visíveis sem animação de entrada individual, evitando movimento desnecessário e mantendo a progressão automática da experiência.

## Testes/documentação

- Atualizado `tests/journey.spec.js` para refletir que a Sala Comunal está disponível.
- O teste agora verifica a montagem do canvas Three.js e o retorno ao Salão Principal.
- Atualizado o README para usar `npx netlify dev --port 8889`, evitando depender de uma instalação global do Netlify CLI.

## Verificação realizada

Foi feita comparação entre a versão original do ZIP e esta versão corrigida, além de verificações estáticas dos pontos alterados.

Não foi possível concluir `npm ci` dentro do ambiente desta sessão: a instalação de dependências excedeu o tempo de transporte disponível. Por isso, **não foi declarado que `vite build` ou Playwright foram executados com sucesso**. O código foi corrigido estaticamente e o pacote continua contendo o `package-lock.json` original para instalação normal no ambiente de desenvolvimento/CI.

## Próximo passo recomendado

No seu computador ou CI:

```bash
npm ci
npm run build
```

E, para os testes de navegador:

```bash
npx playwright install chromium
npx playwright test
```

## Cerimônia de seleção em vídeo
- A cerimônia agora usa o vídeo completo `public/video/cerimonia-selecao-bia.mp4` (aprox. 222,4 s).
- As três falas de introdução foram adaptadas para a narração do Professor Fig, mantendo a ideia enviada pela usuária.
- O vídeo entra com fade-in após as três falas e termina com fade-out antes da revelação da casa.
- O áudio original do vídeo é preservado; a reprodução tenta iniciar com áudio e faz fallback para mudo se o navegador bloquear autoplay com som.
